"""Decode and inspect the delivered MP4, including its intentional light blink."""
from pathlib import Path
import json,re,subprocess,sys
import cv2
import numpy as np
from PIL import Image,ImageDraw,ImageFont
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(OUT/'source'))
from timeline import FRAME_COUNT,FPS,PREVIEWS,SHOTS
video=OUT/'NOMAD_다크리빌_GNSS_v6_8_4초_무음.mp4'
ff='/tmp/nomad-video-deps/ffmpeg'
decoded=subprocess.run([ff,'-hide_banner','-nostdin','-i',str(video),'-f','null','-'],capture_output=True,text=True)
assert decoded.returncode==0,decoded.stderr
assert not re.search(r'Stream .*Audio:',decoded.stderr),decoded.stderr
assert '1920x1080' in decoded.stderr
cap=cv2.VideoCapture(str(video));assert cap.isOpened()
fps=cap.get(cv2.CAP_PROP_FPS);assert abs(fps-FPS)<1e-6
cut_frames=list(range(150,166))
want=set(PREVIEWS+[214,218,222]+cut_frames)
black=[a for name,a,b in SHOTS if name=='black']
want.update(black)
images={};n=0
while True:
    ok,frame=cap.read()
    if not ok:break
    n+=1
    if n in want:images[n]=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
cap.release();assert n==FRAME_COUNT,(n,FRAME_COUNT)
for f in black:assert images[f].mean()<1,(f,float(images[f].mean()))
geometry=json.loads((OUT/'scene_checks.json').read_text())
blink={}
for f in [214,218,222]:
    blink[str(f)]={}
    for side in ['L','R']:
        x,y=map(round,geometry['lamp_samples'][str(f)][side]['center_px'])
        roi=images[f][y-20:y+21,x-45:x+46]
        blink[str(f)][side]={'mean':round(float(roi.mean()),2),
            'bright_pixels':int((roi.min(axis=2)>220).sum())}
for side in ['L','R']:
    off=blink['218'][side]['bright_pixels']
    assert blink['214'][side]['bright_pixels']>off+20,blink
    assert blink['222'][side]['bright_pixels']>off+20,blink
sheet=Image.new('RGB',(1440,846),'black')
for i,f in enumerate(PREVIEWS):
    im=Image.fromarray(images[f]);im.thumbnail((480,270))
    sheet.paste(im,((i%3)*480,(i//3)*282))
sheet.save(OUT/'완성영상_검수.jpg',quality=94)
blink_sheet=Image.new('RGB',(1440,270),'black')
for i,f in enumerate([214,218,222]):
    im=Image.fromarray(images[f]);im.thumbnail((480,270));blink_sheet.paste(im,(480*i,0))
blink_sheet.save(OUT/'쌍라이트_깜빡임_검수.jpg',quality=94)
cut_sheet=Image.new('RGB',(1440,864),(10,14,18))
draw=ImageDraw.Draw(cut_sheet)
for i,f in enumerate(cut_frames):
    im=Image.fromarray(images[f]);im.thumbnail((360,202))
    x,y=(i%4)*360,(i//4)*216
    cut_sheet.paste(im,(x,y));draw.text((x+8,y+203),f'Frame {f}  |  {(f-1)/fps:.3f} s',fill=(225,235,240))
cut_sheet.save(OUT/'바퀴_정면_전환_프레임검수.jpg',quality=96)
report={'file':video.name,'bytes':video.stat().st_size,'size':[1920,1080],
        'frames':n,'fps':fps,'duration_seconds':n/fps,'audio_streams':0,
        'full_decode':'passed','intentional_black_cut_frames':black,
        'single_synchronous_blink':blink,'blue_gnss_in_closing':'visible in rendered closing frames',
        'wheel_to_front_cut_review_frames':cut_frames,
        'shot_order':[name for name,a,b in SHOTS if name!='black']}
(OUT/'검수결과.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
