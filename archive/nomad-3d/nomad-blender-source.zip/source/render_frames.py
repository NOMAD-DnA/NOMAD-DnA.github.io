import bpy,sys,os,time
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(OUT/'source'))
from timeline import FRAME_COUNT,FPS,config_at_frame,safe_blur
scene=bpy.context.scene;scene.render.resolution_percentage=100;scene.render.image_settings.compression=15
pending=[f for f in range(1,FRAME_COUNT+1) if not (OUT/'frames'/f'frame_{f:04d}.png').exists()]
for arg in sys.argv:
    if arg.startswith('--frames='):pending=[int(f) for f in arg.split('=',1)[1].split(',')]
start=time.monotonic()
for i,f in enumerate(pending):
    scene.frame_set(f);scene.render.use_motion_blur=safe_blur(f)
    scene.render.motion_blur_shutter=.20;scene.eevee.motion_blur_steps=4
    # The last spinning frame exposes only into the past, entirely before the cut.
    scene.render.motion_blur_position='END' if f==157 else 'CENTER'
    scene.eevee.taa_render_samples=16 if safe_blur(f) else 24
    path=OUT/'frames'/f'frame_{f:04d}.png';temp=path.with_name('rendering.png')
    scene.render.filepath=str(temp);bpy.ops.render.render(write_still=True);os.replace(temp,path)
    print('PROGRESS',i+1,len(pending),'FRAME',f,round(time.monotonic()-start,1),flush=True)
