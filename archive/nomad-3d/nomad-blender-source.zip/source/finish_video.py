"""Edit the actual Blender render into the final silent 8.4-second product film."""
from pathlib import Path
import sys, subprocess, json, math, time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from timeline import SHOTS,PREVIEWS,config_at_frame,FRAME_COUNT,FPS,DURATION
WORK=Path('/tmp/nomad-3d-v6-work');WORK.mkdir(exist_ok=True)
FF='/tmp/nomad-video-deps/ffmpeg'
W,H=1920,1080
FONT='/usr/share/fonts/truetype/noto/NotoSansDisplay-'
fonts={}
def font(n,bold=False):
    k=(n,bold)
    if k not in fonts:fonts[k]=ImageFont.truetype(FONT+('Bold' if bold else 'Light')+'.ttf',n)
    return fonts[k]
def sm(a,b,x):
    x=np.clip((x-a)/(b-a),0,1);return x*x*(3-2*x)
def tracked(d,xy,text,size,space,color,bold=False):
    x,y=xy;f=font(size,bold)
    for c in text:d.text((x,y),c,font=f,fill=color,anchor='lt');x+=d.textlength(c,font=f)+space

def edited(im,t):
    im=im.convert('RGB')
    if im.size!=(W,H):im=im.resize((W,H),Image.Resampling.LANCZOS)
    layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
    # A restrained film matte; keep the full vehicle inside the safe picture area.
    d.rectangle((0,0,W,57),fill=(0,0,0,255));d.rectangle((0,H-57,W,H),fill=(0,0,0,255))
    if t>=184/30:
        a=float(sm(6.38,6.80,t)*(1-sm(8.06,8.4,t)))
        c=(225,233,239,int(a*255));accent=(95,182,202,int(a*255))
        tracked(d,(108,392),'TEAM NOMAD',17,5,accent)
        tracked(d,(99,442),'NOMAD',83,9,c,True)
        d.line((108,562,162,562),fill=accent,width=2)
        tracked(d,(108,592),'SEE. SENSE. MOVE.',20,3,(170,187,201,int(a*255)))
    im=Image.alpha_composite(im.convert('RGBA'),layer).convert('RGB')
    # Intentional black edit points and final dissolve, in addition to physical light fades.
    fade=float(sm(0,.10,t)*(1-sm(8.06,8.4,t)))
    if config_at_frame(min(FRAME_COUNT,round(t*FPS)+1))[0]=='black':fade=0
    if fade<1:im=Image.fromarray(np.uint8(np.asarray(im,dtype=np.float32)*fade))
    return im

if '--preview' in sys.argv:
    sheet=Image.new('RGB',(1440,846),'black')
    for i,f in enumerate(PREVIEWS):
        im=edited(Image.open(OUT/f'preview_{f:03d}.png'),(f-1)/FPS)
        im.save(OUT/f'composition_{f:03d}.jpg',quality=94)
        im.thumbnail((480,270));sheet.paste(im,((i%3)*480,(i//3)*282))
    sheet.save(OUT/'구도검수.jpg',quality=94)
    raise SystemExit()

silent=WORK/'3d_picture.mp4';log=(WORK/'encode.log').open('w')
p=subprocess.Popen([FF,'-hide_banner','-nostdin','-v','warning','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1920x1080','-framerate','30','-i','pipe:0','-an','-vf','scale=out_color_matrix=bt709:out_range=tv','-c:v','libx264','-preset','slow','-crf','17','-threads','4','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart',str(silent)],stdin=subprocess.PIPE,stderr=log)
for i in range(FRAME_COUNT):
    path=OUT/'frames'/f'frame_{i+1:04d}.png'
    while True:
        try:
            if '--stream' in sys.argv and i<FRAME_COUNT-1 and not (OUT/'frames'/f'frame_{i+2:04d}.png').exists():
                time.sleep(.5);continue
            with Image.open(path) as src:
                src.load();raw=src.copy()
            break
        except (FileNotFoundError,OSError,SyntaxError):
            if '--stream' not in sys.argv:raise
            time.sleep(.5)
    im=edited(raw,i/FPS)
    p.stdin.write(im.tobytes())
    if i==233:im.save(OUT/'미리보기.jpg',quality=96)
    if i%60==0:print('Edited',i,'/',FRAME_COUNT,'frames',flush=True)
p.stdin.close();assert p.wait()==0;log.close()
output=OUT/'NOMAD_다크리빌_GNSS_v6_8_4초_무음.mp4'
subprocess.run([FF,'-hide_banner','-nostdin','-v','error','-y','-i',str(silent),'-map','0:v:0','-c:v','copy','-an','-movflags','+faststart','-metadata','title=NOMAD | Wheel Spin and Twin Light Blink | Silent 8.4 s',str(output)],check=True)
print('Completed:',output,output.stat().st_size,flush=True)
