"""Read-only geometric and animation checks for the final teaser."""
import bpy, sys, json, math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
OUT=Path(__file__).resolve().parents[1]
scene=bpy.context.scene
def pixel(point):
    v=world_to_camera_view(scene,scene.camera,Vector(point))
    return [round(v.x*1920,2),round((1-v.y)*1080,2)]
data={'frame_count':scene.frame_end-scene.frame_start+1,'fps':scene.render.fps,
      'gnss_objects':[o.name for o in bpy.data.objects if o.name.startswith('GNSS')],
      'lamp_samples':{},'gnss_projection':{},'wheel_rotation_rad':{}}
for f in [214,218,222,234]:
    scene.frame_set(f)
    data['lamp_samples'][str(f)]={side:{
        'center_px':pixel((x,-.319,.379)),
        'emission':bpy.data.materials['Twin lamps / '+side+' white LED'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value,
        'light_energy':bpy.data.objects['Twin lamp '+side+' practical beam'].data.energy}
        for side,x in [('L',-.145),('R',.145)]}
    data['gnss_projection'][str(f)]=pixel(bpy.data.objects['GNSS tapered radome'].location)
for f in [140,146,152,157]:
    scene.frame_set(f)
    data['wheel_rotation_rad'][str(f)]=[o.rotation_euler.x for o in bpy.data.objects if o.name.startswith('Wheel spin axle /')]
assert len(data['gnss_objects'])>=4
for side in ['L','R']:
    assert data['lamp_samples']['214'][side]['emission']>7
    assert data['lamp_samples']['218'][side]['emission']==0
    assert data['lamp_samples']['222'][side]['emission']>7
assert abs(data['wheel_rotation_rad']['157'][0])>6
(OUT/'scene_checks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Scene checks passed: blue GNSS, four spinning wheels and one synchronous light blink.')
