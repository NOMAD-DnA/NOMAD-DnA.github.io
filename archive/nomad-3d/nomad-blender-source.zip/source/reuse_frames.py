"""Exact source-frame reuse for unchanged approved shots; never use the old wheel shot."""
from pathlib import Path
import shutil,json
from timeline import FRAME_COUNT,PREVIEWS,source_frame,new_render
OUT=Path(__file__).resolve().parents[1]
SRC=OUT.parent/'nomad_3d_teaser_v5'/'frames'
mapping={}
for f in range(1,FRAME_COUNT+1):
    if new_render(f):continue
    sf=source_frame(f);src=SRC/f'frame_{sf:04d}.png';assert src.exists()
    shutil.copy2(src,OUT/'frames'/f'frame_{f:04d}.png');mapping[f]=sf
    if f in PREVIEWS:shutil.copy2(src,OUT/f'preview_{f:03d}.png')
(OUT/'source_frame_map.json').write_text(json.dumps(mapping,indent=2)+'\n')
print('Reused',len(mapping),'unchanged frames; wheel detail, spin and closing frames remain.')
