FPS=30
FRAME_COUNT=252
DURATION=FRAME_COUNT/FPS
SHOTS=[('intro',1,30),('black',31,32),('lamp',33,56),('black',57,58),
       ('lidar',59,82),('black',83,84),('wheel',85,108),('black',109,110),
       ('side',111,137),('black',138,139),('spin',140,157),('black',158,159),
       ('front',160,182),('black',183,184),('hero',185,252)]
SOURCES={'intro':(1,47),'lamp':(50,87),'lidar':(91,123),'side':(166,204),
         'front':(208,231),'hero':(232,300)}
PREVIEWS=[16,47,70,98,124,153,171,218,234]
BLINK={215:.6,216:.05,217:0,218:0,219:0,220:.05,221:.6}
def config_at_frame(f):
    for name,a,b in SHOTS:
        if a<=f<=b:return name,(f-a)/max(1,b-a)
    raise ValueError(f)
def source_frame(f):
    name,u=config_at_frame(f)
    if name=='black':return 49
    if name in ['wheel','spin']:return 184
    a,b=SOURCES[name];return round(a+(b-a)*u)
def new_render(f):return config_at_frame(f)[0] in ['wheel','spin','hero']
def safe_blur(f):return 141<=f<=157
