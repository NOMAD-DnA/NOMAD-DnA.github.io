"""8.4-second silent recut. Original 3D wheel spin and one synchronous lamp blink."""
import bpy,sys,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(OUT/'source'))
from timeline import FPS,FRAME_COUNT,DURATION,PREVIEWS,BLINK,source_frame,config_at_frame,safe_blur
bpy.ops.wm.open_mainfile(filepath=str(OUT/'source'/'NOMAD_기준모델.blend'))
scene=bpy.context.scene;cam=scene.camera;focus=bpy.data.objects['Focus target']
vehicle=bpy.data.collections['NOMAD | reconstructed vehicle']
names=['Animated white strip','Cold rim strip','Large soft reflection','Neutral opposing edge',
       'Moving silhouette backlight','Studio / overhead edge','Twin lamp L practical beam','Twin lamp R practical beam']
lights=[bpy.data.objects[n] for n in names]
ambient=scene.world.node_tree.nodes['Background'].inputs['Strength']
status=bpy.data.materials['13 • restrained ice-blue status'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength']
leds=[bpy.data.materials['Twin lamps / '+s+' white LED'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'] for s in ['L','R']]
panels=[bpy.data.materials['Studio / slit %02d'%i].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'] for i in range(7)]
sockets=[ambient,status]+leds+panels
pivots=[o for o in vehicle.objects if o.name.startswith('Wheel spin axle /')];assert len(pivots)==4
snapshots={}
for f in range(1,FRAME_COUNT+1):
    scene.frame_set(source_frame(f))
    snapshots[f]={'cam':tuple(cam.location),'rot':tuple(cam.rotation_euler),'lens':cam.data.lens,
      'focus':tuple(focus.location),'lights':[(tuple(o.location),tuple(o.rotation_euler),o.data.energy) for o in lights],
      'sockets':[s.default_value for s in sockets]}
animated=[cam,cam.data,focus,scene.world.node_tree]+lights+[o.data for o in lights]+pivots
for m in bpy.data.materials:
    if m.node_tree:animated.append(m.node_tree)
for d in animated:d.animation_data_clear()
def sm(x):x=max(0,min(1,x));return x*x*(3-2*x)
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
for f in range(1,FRAME_COUNT+1):
    d=snapshots[f];name,u=config_at_frame(f);s=sm(u)
    cam.location=d['cam'];cam.rotation_euler=d['rot'];cam.data.lens=d['lens'];focus.location=d['focus']
    for o,(loc,rot,power) in zip(lights,d['lights']):o.location=loc;o.rotation_euler=rot;o.data.energy=power
    for socket,v in zip(sockets,d['sockets']):socket.default_value=v
    for o in pivots:o.rotation_euler=(0,0,0)
    if name in ['wheel','spin']:
        # Two distinct shots: machined wheel detail, then a brief powered spin.
        if name=='wheel':
            cam.location=Vector((.94,-.51,.235)).lerp(Vector((.88,-.34,.215)),s)
            cam.data.lens=52;roll=math.radians(-4+6*s)
            elapsed=0
        else:
            cam.location=Vector((.86,-.37,.215)).lerp(Vector((.96,-.48,.225)),s)
            cam.data.lens=52;roll=math.radians(2-4*s)
            elapsed=max(0,(f-140)/FPS)
        focus.location=(.30,-.252,.135)
        ramp=min(elapsed,.30)
        angle=-2*math.pi*(.5*(3.2/.30)*ramp*ramp+3.2*max(0,elapsed-.30))
        cam.rotation_euler=((focus.location-cam.location).to_track_quat('-Z','Y')@Quaternion((0,0,1),roll)).to_euler()
        for o in pivots:o.rotation_euler.x=angle
        for e in leds:e.default_value=0
        for e in panels:e.default_value=.12
        ambient.default_value=.012;status.default_value=0
        lights[0].location=(1.0,-.8+1.0*s,.70);aim(lights[0],(.26,-.252,.14))
        lights[1].location=(-.6,-.1,.65);aim(lights[1],(.20,-.25,.20))
        lights[2].location=(.8,-.8,.35);aim(lights[2],(.25,-.25,.14))
        lights[3].location=(.7,.35,.6);aim(lights[3],(.25,-.25,.14))
        env=sm(u/.10)*(sm((1-u)/.10) if name=='wheel' else 1)
        for o,p in zip(lights,[38,18,6,12,0,4,0,0]):o.data.energy=p*env
    elif name=='hero':
        # Front-left quarter separates the existing rear GNSS from the LiDAR.
        # Keep the actual estimated sensor mounting positions unchanged.
        cam.location=Vector((-.85,-1.95,1.04)).lerp(Vector((-.48,-1.94,.98)),s)
        focus.location=(-.17,0,.42);cam.data.lens=34
        cam.rotation_euler=((focus.location-cam.location).to_track_quat('-Z','Y')@Quaternion((0,0,1),math.radians(1-s))).to_euler()
        lights[0].location=(-1.15+.45*s,-1.0,1.30);aim(lights[0],(0,0,.48))
        lights[1].location=(.75,.45,1.25);aim(lights[1],(0,.05,.55))
        lights[2].location=(-.25,-1.2,.85);aim(lights[2],(0,0,.48))
        lights[3].location=(-.8,.55,1.1);aim(lights[3],(-.094,.156,.76))
    if f in BLINK:
        for e in leds:e.default_value*=BLINK[f]
        for l in lights[-2:]:l.data.energy*=BLINK[f]
    for o in [cam,focus]:o.keyframe_insert('location',frame=f)
    cam.keyframe_insert('rotation_euler',frame=f);cam.data.keyframe_insert('lens',frame=f)
    for o in lights:
        o.keyframe_insert('location',frame=f);o.keyframe_insert('rotation_euler',frame=f);o.data.keyframe_insert('energy',frame=f)
    for o in pivots:o.keyframe_insert('rotation_euler',frame=f)
    for socket in sockets:socket.keyframe_insert('default_value',frame=f)
for action in bpy.data.actions:
    for fc in action.fcurves:
        for k in fc.keyframe_points:k.interpolation='LINEAR'
scene.frame_start=1;scene.frame_end=FRAME_COUNT;scene.render.fps=FPS
scene.render.resolution_percentage=100;scene.render.use_motion_blur=False;scene.eevee.taa_render_samples=24
scene.frame_set(234);bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'NOMAD_휠스핀_라이트깜빡임_8_4초.blend'))
(OUT/'model_notes.json').write_text(json.dumps({
 'version':'v6 silent 8.4-second wheel-and-blink edit','duration_seconds':DURATION,'frames':FRAME_COUNT,
 'shot_order':['side silhouette','lamp ignition','lidar','wheel detail','side panel','brief wheel spin','front','NOMAD closing with visible blue GNSS and one simultaneous twin-light blink'],
 'removed':['OAK closeup shot','entire audio stream'],
 'wheel':'Actual rigid wheel assemblies rotate about their existing axles. Short shutter and blur only within the wheel shot; the final spin frame uses an end-position shutter so its exposure stays before the cut.',
 'blink':'Both emissive LED housings and actual lamp light sources dim together once in frames 215–221, returning to their original brightness at 222.',
 'reuse':'Unchanged v5 raw frames sampled exactly; newly rendered wheel detail, spin and entire closing shot. Rejected old wheel footage is never used.',
 'model_geometry':'The existing blue GNSS antenna behind the LiDAR is revealed by a new front-left closing camera angle. Original GNSS position and size retained. Connected-chassis and twin-LED visualization, visually estimated rather than measured CAD.'
},ensure_ascii=False,indent=2)+'\n')
if '--preview' in sys.argv:
    scene.render.resolution_percentage=60
    for f in [98,153,203,218,234]:
        scene.frame_set(f);scene.render.use_motion_blur=safe_blur(f)
        scene.render.motion_blur_shutter=.20;scene.eevee.motion_blur_steps=4
        scene.eevee.taa_render_samples=16 if safe_blur(f) else 24
        scene.render.filepath=str(OUT/f'preview_{f:03d}.png');bpy.ops.render.render(write_still=True)
